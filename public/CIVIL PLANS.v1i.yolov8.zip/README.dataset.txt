# CIVIL PLANS > 2026-05-24 9:17pm
https://universe.roboflow.com/mayank-kbzkg/civil-plans

Provided by a Roboflow user
License: CC BY 4.0

